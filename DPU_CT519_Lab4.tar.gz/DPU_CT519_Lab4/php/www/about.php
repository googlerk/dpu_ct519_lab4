<?php 
//Piyawat Loawthong
?>

<html>
<head>
    <link href="https://unpkg.com/tabulator-tables@5.2.3/dist/css/tabulator.min.css" rel="stylesheet">
    <script type="text/javascript" src="https://unpkg.com/tabulator-tables@5.2.3/dist/js/tabulator.min.js"></script>
</head>
<body>
    <?php 
        phpinfo();
    ?>
</body>
</html>